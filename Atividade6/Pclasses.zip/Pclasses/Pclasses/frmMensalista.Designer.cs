﻿
namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblDataEntrada = new System.Windows.Forms.Label();
            this.lblSalrioMensal = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtDataEntrada = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.btnIntanciar1 = new System.Windows.Forms.Button();
            this.btnInstanciar2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblMatricula.Location = new System.Drawing.Point(33, 57);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(65, 18);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblNome.Location = new System.Drawing.Point(33, 111);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(46, 18);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // lblDataEntrada
            // 
            this.lblDataEntrada.AutoSize = true;
            this.lblDataEntrada.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDataEntrada.Location = new System.Drawing.Point(33, 165);
            this.lblDataEntrada.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDataEntrada.Name = "lblDataEntrada";
            this.lblDataEntrada.Size = new System.Drawing.Size(181, 18);
            this.lblDataEntrada.TabIndex = 2;
            this.lblDataEntrada.Text = "Data de entrada na empresa";
            // 
            // lblSalrioMensal
            // 
            this.lblSalrioMensal.AutoSize = true;
            this.lblSalrioMensal.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSalrioMensal.Location = new System.Drawing.Point(33, 219);
            this.lblSalrioMensal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalrioMensal.Name = "lblSalrioMensal";
            this.lblSalrioMensal.Size = new System.Drawing.Size(98, 18);
            this.lblSalrioMensal.TabIndex = 3;
            this.lblSalrioMensal.Text = "Salário mensal";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(236, 46);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(113, 26);
            this.txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(236, 100);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(245, 26);
            this.txtNome.TabIndex = 5;
            // 
            // txtDataEntrada
            // 
            this.txtDataEntrada.Location = new System.Drawing.Point(236, 154);
            this.txtDataEntrada.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDataEntrada.Name = "txtDataEntrada";
            this.txtDataEntrada.Size = new System.Drawing.Size(113, 26);
            this.txtDataEntrada.TabIndex = 6;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(236, 208);
            this.txtSalario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(113, 26);
            this.txtSalario.TabIndex = 7;
            // 
            // btnIntanciar1
            // 
            this.btnIntanciar1.BackColor = System.Drawing.Color.White;
            this.btnIntanciar1.Location = new System.Drawing.Point(64, 311);
            this.btnIntanciar1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnIntanciar1.Name = "btnIntanciar1";
            this.btnIntanciar1.Size = new System.Drawing.Size(111, 66);
            this.btnIntanciar1.TabIndex = 8;
            this.btnIntanciar1.Text = "Instanciar Mensalista";
            this.btnIntanciar1.UseVisualStyleBackColor = false;
            this.btnIntanciar1.Click += new System.EventHandler(this.btnIntanciar1_Click);
            // 
            // btnInstanciar2
            // 
            this.btnInstanciar2.BackColor = System.Drawing.Color.White;
            this.btnInstanciar2.Location = new System.Drawing.Point(277, 311);
            this.btnInstanciar2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnInstanciar2.Name = "btnInstanciar2";
            this.btnInstanciar2.Size = new System.Drawing.Size(115, 66);
            this.btnInstanciar2.TabIndex = 9;
            this.btnInstanciar2.Text = "Instanciar Com Parâmetros";
            this.btnInstanciar2.UseVisualStyleBackColor = false;
            this.btnInstanciar2.Click += new System.EventHandler(this.btnInstanciar2_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(516, 392);
            this.Controls.Add(this.btnInstanciar2);
            this.Controls.Add(this.btnIntanciar1);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtDataEntrada);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblSalrioMensal);
            this.Controls.Add(this.lblDataEntrada);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblDataEntrada;
        private System.Windows.Forms.Label lblSalrioMensal;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtDataEntrada;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.Button btnIntanciar1;
        private System.Windows.Forms.Button btnInstanciar2;
    }
}