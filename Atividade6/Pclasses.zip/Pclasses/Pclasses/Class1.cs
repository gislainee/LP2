﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract class Empregado
    {// atributos
        private int matricula;
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        //ppropriedades
        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }

        }
        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        // metodos
        public abstract double SalarioBruto();

        public virtual int TempoTrabalho()
        {
            TimeSpan ts = DateTime.Today.Subtract(DataEntradaEmpresa);
            return ts.Days;
        }
    }
}
