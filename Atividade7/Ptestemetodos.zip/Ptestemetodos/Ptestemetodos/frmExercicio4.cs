﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btnQntNum_Click(object sender, EventArgs e)
        {
            int contador = 0;

            while (contador < txtTexto.Text.Length)
            {
                if (Char.IsNumber(txtTexto.Text[contador]))
                    break;

                contador++;
            }

            MessageBox.Show("A posicao do primeiro caracter numerico eh: " + contador);
        }

        private void btnCaracter_Click(object sender, EventArgs e)
        {
            int contador = 0;

            while (contador < txtTexto.Text.Length)
            {
                if (Char.IsWhiteSpace(txtTexto.Text[contador]))
                    break;

                contador++;
            }

            MessageBox.Show("A posicao do primeiro caracter branco é: " + contador);
        }

        private void btnCaracter_Click_1(object sender, EventArgs e)
        {
            int contador = 0;

            while (contador < txtTexto.Text.Length)
            {
                if (Char.IsLetter(txtTexto.Text[contador]))
                    break;

                contador++;
            }

            MessageBox.Show("A posicao do primeiro caracter de letra é: " + contador);
        }
    }
}
