﻿
namespace Ptestemetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTexto = new System.Windows.Forms.RichTextBox();
            this.btnQntNum = new System.Windows.Forms.Button();
            this.btnLocalizaCaracter = new System.Windows.Forms.Button();
            this.btnCaracter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(111, 21);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(100, 96);
            this.txtTexto.TabIndex = 0;
            this.txtTexto.Text = "";
            // 
            // btnQntNum
            // 
            this.btnQntNum.Location = new System.Drawing.Point(38, 170);
            this.btnQntNum.Name = "btnQntNum";
            this.btnQntNum.Size = new System.Drawing.Size(123, 48);
            this.btnQntNum.TabIndex = 1;
            this.btnQntNum.Text = "Quantidade de numeros";
            this.btnQntNum.UseVisualStyleBackColor = true;
            this.btnQntNum.Click += new System.EventHandler(this.btnQntNum_Click);
            // 
            // btnLocalizaCaracter
            // 
            this.btnLocalizaCaracter.Location = new System.Drawing.Point(215, 169);
            this.btnLocalizaCaracter.Name = "btnLocalizaCaracter";
            this.btnLocalizaCaracter.Size = new System.Drawing.Size(102, 49);
            this.btnLocalizaCaracter.TabIndex = 2;
            this.btnLocalizaCaracter.Text = "Localiza caracter";
            this.btnLocalizaCaracter.UseVisualStyleBackColor = true;
            this.btnLocalizaCaracter.Click += new System.EventHandler(this.btnCaracter_Click);
            // 
            // btnCaracter
            // 
            this.btnCaracter.Location = new System.Drawing.Point(374, 169);
            this.btnCaracter.Name = "btnCaracter";
            this.btnCaracter.Size = new System.Drawing.Size(109, 49);
            this.btnCaracter.TabIndex = 3;
            this.btnCaracter.Text = "Quantidade Caracter";
            this.btnCaracter.UseVisualStyleBackColor = true;
            this.btnCaracter.Click += new System.EventHandler(this.btnCaracter_Click_1);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 309);
            this.Controls.Add(this.btnCaracter);
            this.Controls.Add(this.btnLocalizaCaracter);
            this.Controls.Add(this.btnQntNum);
            this.Controls.Add(this.txtTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.frmExercicio4_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtTexto;
        private System.Windows.Forms.Button btnQntNum;
        private System.Windows.Forms.Button btnLocalizaCaracter;
        private System.Windows.Forms.Button btnCaracter;
    }
}