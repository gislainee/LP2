﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Random sorteio = new Random();
            int num1 = Convert.ToInt32(txtNum1);
            int num2 = Convert.ToInt32(txtNum2);

            string resultado = "";

            for (int i = 1; i <= 10; i++)
            {
                resultado = resultado + " " + sorteio.Next(num1, num2);
            }
        }
    }
}
