﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace P0030482111001
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double total = 0;
            double fat = 0;
            double[,] venda = new double[1, 4];

            for (int mes = 0; mes < venda.GetLength(0); mes++)

            {
                for (int sem = 0; sem < venda.GetLength(1); sem++)
                {
                    if (!double.TryParse(Interaction.InputBox($"Digite a venda do mês: {mes + 1} " +
                        $"controle de venda"), out venda[mes, sem]))
                    {
                        MessageBox.Show("Valor invalido");
                        sem--;
                    }
                    else
                        listVendas.Items.Add(" Total do mês: " + (mes + 1) + " " + "Semana: " + (sem + 1) + " R$" + (venda.Length));
                        total += venda[mes, sem];
                }
                listVendas.Items.Add("Total do mês: " + (mes + 1) + " " + total);
            }
        }
    }
}
