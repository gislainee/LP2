﻿
namespace Atividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspacosBrancos = new System.Windows.Forms.Button();
            this.btnNumR = new System.Windows.Forms.Button();
            this.btnParLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchFrase
            // 
            this.rchFrase.Location = new System.Drawing.Point(12, 21);
            this.rchFrase.Name = "rchFrase";
            this.rchFrase.Size = new System.Drawing.Size(210, 158);
            this.rchFrase.TabIndex = 0;
            this.rchFrase.Text = "";
            this.rchFrase.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // btnEspacosBrancos
            // 
            this.btnEspacosBrancos.BackColor = System.Drawing.SystemColors.Info;
            this.btnEspacosBrancos.Location = new System.Drawing.Point(243, 21);
            this.btnEspacosBrancos.Name = "btnEspacosBrancos";
            this.btnEspacosBrancos.Size = new System.Drawing.Size(147, 36);
            this.btnEspacosBrancos.TabIndex = 1;
            this.btnEspacosBrancos.Text = "Espacos Brancos";
            this.btnEspacosBrancos.UseVisualStyleBackColor = false;
            this.btnEspacosBrancos.Click += new System.EventHandler(this.btnEspacosBrancos_Click);
            // 
            // btnNumR
            // 
            this.btnNumR.BackColor = System.Drawing.SystemColors.Info;
            this.btnNumR.Location = new System.Drawing.Point(243, 83);
            this.btnNumR.Name = "btnNumR";
            this.btnNumR.Size = new System.Drawing.Size(147, 37);
            this.btnNumR.TabIndex = 2;
            this.btnNumR.Text = "Nº de \"R\"";
            this.btnNumR.UseVisualStyleBackColor = false;
            this.btnNumR.Click += new System.EventHandler(this.btnNumR_Click);
            // 
            // btnParLetras
            // 
            this.btnParLetras.BackColor = System.Drawing.SystemColors.Info;
            this.btnParLetras.Location = new System.Drawing.Point(243, 141);
            this.btnParLetras.Name = "btnParLetras";
            this.btnParLetras.Size = new System.Drawing.Size(147, 38);
            this.btnParLetras.TabIndex = 3;
            this.btnParLetras.Text = "Mesmo par de Letras";
            this.btnParLetras.UseVisualStyleBackColor = false;
            this.btnParLetras.Click += new System.EventHandler(this.btnParLetras_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(422, 203);
            this.Controls.Add(this.btnParLetras);
            this.Controls.Add(this.btnNumR);
            this.Controls.Add(this.btnEspacosBrancos);
            this.Controls.Add(this.rchFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchFrase;
        private System.Windows.Forms.Button btnEspacosBrancos;
        private System.Windows.Forms.Button btnNumR;
        private System.Windows.Forms.Button btnParLetras;
    }
}