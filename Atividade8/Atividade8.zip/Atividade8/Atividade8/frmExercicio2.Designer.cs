﻿
namespace Atividade8
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGerarH = new System.Windows.Forms.Button();
            this.rchH = new System.Windows.Forms.RichTextBox();
            this.lblNum = new System.Windows.Forms.Label();
            this.txtN = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnGerarH
            // 
            this.btnGerarH.BackColor = System.Drawing.SystemColors.Info;
            this.btnGerarH.Location = new System.Drawing.Point(290, 132);
            this.btnGerarH.Name = "btnGerarH";
            this.btnGerarH.Size = new System.Drawing.Size(147, 38);
            this.btnGerarH.TabIndex = 7;
            this.btnGerarH.Text = "Gerar H";
            this.btnGerarH.UseVisualStyleBackColor = false;
            this.btnGerarH.Click += new System.EventHandler(this.btnGerarH_Click);
            // 
            // rchH
            // 
            this.rchH.Location = new System.Drawing.Point(12, 59);
            this.rchH.Name = "rchH";
            this.rchH.Size = new System.Drawing.Size(425, 67);
            this.rchH.TabIndex = 4;
            this.rchH.Text = "";
            // 
            // lblNum
            // 
            this.lblNum.AutoSize = true;
            this.lblNum.Location = new System.Drawing.Point(30, 22);
            this.lblNum.Name = "lblNum";
            this.lblNum.Size = new System.Drawing.Size(104, 15);
            this.lblNum.TabIndex = 8;
            this.lblNum.Text = "Digite um numero";
            this.lblNum.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(154, 22);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(283, 23);
            this.txtN.TabIndex = 9;
            this.txtN.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(449, 187);
            this.Controls.Add(this.txtN);
            this.Controls.Add(this.lblNum);
            this.Controls.Add(this.btnGerarH);
            this.Controls.Add(this.rchH);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGerarH;
        private System.Windows.Forms.RichTextBox rchH;
        private System.Windows.Forms.Label lblNum;
        private System.Windows.Forms.TextBox txtN;
    }
}