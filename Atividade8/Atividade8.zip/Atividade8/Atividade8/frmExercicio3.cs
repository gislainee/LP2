﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            txtFrase.Text = txtFrase.Text.ToUpper();
            txtFrase.Text = txtFrase.Text.Replace(" ", "");

            string inversa = txtFrase.Text;
            char[] aux = inversa.ToCharArray();
            Array.Reverse(aux);
            inversa = "";
            foreach (char c in aux)
                inversa += c.ToString();

            txtInvertida.Text = inversa;

            if (String.Compare(txtFrase.Text, inversa) == 0)
            {
                MessageBox.Show("É um palíndromo");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo");
            }
        }
    }
}
